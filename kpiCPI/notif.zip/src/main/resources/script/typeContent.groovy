/*
 Підготуємо шаблон для повідомлення, 
 та встановимо хеадер Content-Type -> application/json
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    def template = ""+
        "{" +
        "    \"NotificationTypeKey\": \"infoKPI\"," +
        "    \"NotificationTypeVersion\": \"1.0\","+
        "    \"Templates\": [ "+
        "        {" +
        "            \"Language\": \"en\"," +
        "            \"TemplatePublic\": \"Завдання по SAP CPI виконано успішно\","+
        "            \"TemplateSensitive\": \"Завдання {{firstName}} {{lastName}} виконано успішно ({{department}})\","+
        "            \"TemplateGrouped\": \"\"," +
        "            \"TemplateLanguage\": \"Mustache\"," +
        "            \"Subtitle\": \"Ідентифікатор завдання {{verificationCode}}\""+
        "        }"+
        "    ],"+
        "    \"Actions\": ["+
        "        {"+
        "            \"ActionId\": \"AcceptLRActionKey\"," +
        "            \"Language\": \"en\","+
        "            \"ActionText\": \"Погодитися\","+
        "            \"GroupActionText\": \"Accept All\","+
        "            \"Nature\": \"POSITIVE\""+
        "        },"+
        "        {"+
        "            \"ActionId\": \"RejectLRActionKey\","+
        "            \"Language\": \"en\","+
        "            \"ActionText\": \"Перездати\","+
        "            \"GroupActionText\": \"Reject All\","+
        "            \"Nature\": \"NEGATIVE\""+
        "        }"+
        "    ]"+
        "}";
    message.setBody(template);
    
    //Headers 
    message.setHeader("Content-Type", "application/json");
    
    return message;
}